# src/__init__.py
"""
Source package for EDA Assistant.
"""
